// SPDX-FileCopyrightText: 2026 Anton Wiklund and Solid Memo contributors
//
// SPDX-License-Identifier: MIT

import { expect, type Locator } from "@playwright/test";
import { escapeRegExp } from "../harness/strings.ts";
import { Screen } from "./Screen.ts";

/**
 * The landing page and the WebID form, before anyone is logged in, or
 * while a guest logs in to keep their study (the form shown at once).
 */
export class Onboarding extends Screen {
  async visit(): Promise<void> {
    await this.intent("Visit Solid Memo", async () => {
      await this.page.goto("./");
      await this.expectStart();
    });
  }

  /**
   * Expects the landing page as on a first visit: the guest's offer first,
   * then logging in, then creating a Pod.
   */
  async expectStart(): Promise<void> {
    await expect(this.page.getByRole("main").getByRole("heading", { level: 2 })).toHaveText([
      this.t("onboardingFlow.tryHeading"),
      this.t("onboardingFlow.logInHeading"),
      this.t("onboardingFlow.setUpHeading"),
    ]);
    await expect(this.webIdField).toBeVisible();
  }

  private get webIdField(): Locator {
    return this.page.getByRole("textbox", { name: "WebID" });
  }

  /** Starts the login with a WebID; the browser goes on to its identity provider. */
  async logInWithWebId(webId: string): Promise<void> {
    await this.intent("Log in with the WebID", async () => {
      await this.submitWebId(webId);
    });
  }

  /**
   * Starts the login with a WebID where the WebID form is already shown,
   * as it is to someone who logged out here.
   */
  async logInAgainWithWebId(webId: string): Promise<void> {
    await this.intent("Log in again with the WebID", async () => {
      await this.expectLoggedOut();
      await this.submitWebId(webId);
    });
  }

  /**
   * Submits a WebID the form does not accept: it stays, the field marked
   * invalid and described by the error (errors.<code>).
   */
  async submitRefusedWebId(webId: string, code: string): Promise<void> {
    await this.intent(`Submit the WebID ${webId}, which is refused`, async () => {
      await this.submitWebId(webId);
      await expect(this.webIdField).toHaveAttribute("aria-invalid", "true");
      await expect(this.webIdField).toHaveAccessibleDescription(
        new RegExp(`^${escapeRegExp(this.t(`errors.${code}`))}`),
      );
      await expect(this.webIdField).toBeFocused();
    });
  }

  /**
   * The WebID form, already shown (to a guest logging in to keep their
   * study, or after a WebID refused): the login starts, on to the
   * identity provider.
   */
  async submitWebId(webId: string): Promise<void> {
    await this.intent("Submit the WebID", async () => {
      await this.webIdField.fill(webId);
      await this.page.getByRole("button", { name: this.t("webIdForm.logIn") }).click();
    });
  }

  /** "Try it without logging in": a guest's study starts, in this browser, at its decks. */
  async tryAsGuest(): Promise<void> {
    await this.intent("Try Solid Memo as a guest", async () => {
      await this.page
        .getByRole("button", { name: this.t("onboardingFlow.tryAsGuest"), exact: true })
        .click();
      await this.app.chrome.expectGuest();
      await this.app.decks.expectShown();
    });
  }

  /**
   * Back from the identity provider: the pod it found, then on; with
   * `skipNextTime`, the box checked that skips this screen from now on,
   * and on once the instance's preferences say so.
   */
  async continueConnected(
    pod: string,
    { skipNextTime = false }: { skipNextTime?: boolean } = {},
  ): Promise<void> {
    await this.intent(
      skipNextTime
        ? "Continue with the connected Pod, not to be shown this screen again"
        : "Continue with the connected Pod",
      async () => {
        await expect(
          this.page.getByRole("heading", { name: this.t("podConnection.connectedHeading") }),
        ).toBeVisible({ timeout: 30_000 });
        await expect(this.page.getByRole("main").locator(`a[href="${pod}"]`)).toBeVisible();
        if (skipNextTime)
          await this.page
            .getByRole("checkbox", { name: this.t("podConnection.skipNextTime") })
            .check();
        // The choice is saved after the app opens: one PUT of the preferences.
        const saved = skipNextTime
          ? this.page.waitForResponse(
              (response) =>
                response.request().method() === "PUT" &&
                response.url().endsWith("/preferences.ttl") &&
                response.ok(),
            )
          : null;
        await this.page.getByRole("button", { name: this.t("podConnection.continue") }).click();
        await saved;
      },
    );
  }

  /**
   * Before the identity provider sends the browser back: notes whether
   * the Connected screen shows at any time, for expectConnectedSkipped.
   */
  async watchConnected(): Promise<void> {
    await this.page.addInitScript((heading) => {
      new MutationObserver(() => {
        for (const h2 of document.querySelectorAll("h2"))
          if (h2.textContent === heading) sessionStorage.setItem("journeyConnectedShown", "yes");
      }).observe(document, { childList: true, subtree: true });
    }, this.t("podConnection.connectedHeading"));
  }

  /** Back from the identity provider: the app opens, the Connected screen skipped (watchConnected). */
  async expectConnectedSkipped(): Promise<void> {
    await this.intent("Check that the Connected screen is skipped", async () => {
      await this.app.decks.expectShown();
      expect(
        await this.page.evaluate(() => sessionStorage.getItem("journeyConnectedShown")),
      ).toBeNull();
    });
  }

  /** Expects the landing page as after logging out here: logging in comes first. */
  async expectLoggedOut(): Promise<void> {
    await expect(this.page.getByRole("main").getByRole("heading", { level: 2 }).first()).toHaveText(
      this.t("onboardingFlow.logInHeading"),
    );
    await expect(this.webIdField).toBeVisible();
  }
}
