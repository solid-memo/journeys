// SPDX-FileCopyrightText: 2026 Anton Wiklund and Solid Memo contributors
//
// SPDX-License-Identifier: MIT

import { expect } from "@playwright/test";
import { Screen } from "./Screen.ts";

/**
 * A draft's trial in Solid Memo Studio (docs/studio.md, The trial): the
 * draft played with Solid Memo's own course screens, in a sandbox kept
 * in the page, with the trial's controls above it.
 */
export class Trial extends Screen {
  /** Opens the trial from the draft's tabs: the course's page, ready to start. */
  async open(draft: string): Promise<void> {
    await this.intent(`Try out ${draft}`, async () => {
      await this.app.chrome.studioTab("draft", "trial");
      await expect(
        this.page.getByRole("heading", { level: 2, name: this.t("studio.trial.heading") }),
      ).toBeVisible();
      await expect(
        this.page.getByRole("heading", { level: 3, name: this.t("studio.trial.controls") }),
      ).toBeVisible();
      await expect(
        this.page.getByRole("heading", { level: 2, name: draft, exact: true }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.trial.crumb");
    });
  }

  /**
   * Plays the course's first chapter from its page, to the end of the
   * course, as Solid Memo's own course screens play it (Course.playChapter).
   */
  async playToTheEnd(
    chapter: string,
    theory: string,
    answers: Record<string, string>,
  ): Promise<void> {
    await this.app.course.playChapter(chapter, theory, answers);
  }
}
