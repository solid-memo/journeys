// SPDX-FileCopyrightText: 2026 Anton Wiklund and Solid Memo contributors
//
// SPDX-License-Identifier: MIT

import { expect, type Locator } from "@playwright/test";
import type { AnswerScale } from "./Preferences.ts";
import { escapeRegExp } from "../harness/strings.ts";
import { Screen } from "./Screen.ts";

/** A grade the journeys give: none that puts the card back in the session ("Again", 0–2; see `again`). */
export type Grade = "hard" | "good" | "easy";

export interface StudyResult {
  /** How many answers were given: a card answered Again and then once more counts twice. */
  studied: number;
  /** The session's size as its status line first said it ("Card 1 of {total}"); 0 when there was nothing to study. */
  total: number;
}

/**
 * "Study: {deck}": one card at a time, "Card x of y" in the status line,
 * Reveal, then the answer buttons; at the end "Session finished" (or
 * "Nothing to study today"). "End session" goes back to Decks. Which
 * card comes first is shuffled, so nothing here says which it is.
 */
export class Study extends Screen {
  /** The status line while a card is shown: "Card {position} of {total}". */
  private get statusLine(): Locator {
    return this.page
      .getByRole("main")
      .getByRole("status")
      .filter({ hasText: this.tp("study.position") });
  }

  private get gradeGroup(): Locator {
    return this.page.getByRole("group", { name: this.t("study.gradePrompt") });
  }

  private get finishedMessage(): Locator {
    return this.page.getByRole("main").getByText(this.t("study.finished"), { exact: true });
  }

  private get nothingMessage(): Locator {
    return this.page.getByRole("main").getByText(this.t("study.nothingToday"), { exact: true });
  }

  async expectStudying(deck: string): Promise<void> {
    await expect(
      this.page.getByRole("heading", { name: this.t("study.heading", { deck }) }),
    ).toBeVisible();
  }

  /** The card shown and the session's size, read from "Card x of y" (and what follows it after an Again or an undo). */
  async position(): Promise<{ position: number; total: number }> {
    await expect(this.statusLine).toBeVisible();
    const line = ((await this.statusLine.textContent()) ?? "")
      .replace(`. ${this.t("study.putBack")}`, "")
      .replace(`. ${this.t("study.undone")}`, "");
    const said = this.tp("study.position").exec(line)?.groups;
    if (said === undefined) throw new Error("The study status line says no position.");
    return { position: Number(said.position), total: Number(said.total) };
  }

  /** "Card {position} of {total}" is what the status line says. */
  async expectPosition(position: number, total: number): Promise<void> {
    await expect(this.statusLine).toHaveText(this.t("study.position", { position, total }));
  }

  /**
   * The card shown has "Report a mistake", which opens the library's deck
   * form with `release` and the card filled in: the card's address in
   * `release` (its fragment, whichever card it is).
   */
  async expectReportMistake(release: string): Promise<void> {
    const link = this.page
      .getByRole("main")
      .getByRole("link", { name: this.t("common.reportMistake") });
    await expect(link).toHaveAttribute("target", "_blank");
    const fields = new URL((await link.getAttribute("href")) ?? "").searchParams;
    expect(fields.get("template")).toBe("deck.yml");
    expect(fields.get("deck")).toBe(release);
    expect(fields.get("details")).toMatch(new RegExp(`^Card: ${escapeRegExp(release)}#\\S+\n`));
  }

  /** The side of the card shown that asks: its text, the side's hidden name before it. */
  async question(): Promise<string> {
    return (await this.page.getByRole("main").locator(".study-face").first().innerText()).trim();
  }

  /** The question's picture is not on the page: the choice to show the host's stands in its place. */
  async expectPictureHidden(host: string): Promise<void> {
    await expect(this.showPicturesButton(host)).toBeVisible();
    await expect(this.page.getByRole("main").locator(".study-face img")).toHaveCount(0);
  }

  /** Chooses to show the host's pictures for this deck: the question's takes the choice's place. */
  async showPictures(host: string): Promise<void> {
    await this.intent(`Show pictures from ${host}`, async () => {
      await this.showPicturesButton(host).click();
      await expect(this.showPicturesButton(host)).toHaveCount(0);
      await expect(this.page.getByRole("main").locator(".study-face img").first()).toBeVisible();
    });
  }

  /** How many answers' pictures are in sight, out of the card's. */
  async expectPictureShown(answers: number): Promise<void> {
    await expect(this.page.getByRole("main").locator(".card-answer img:visible")).toHaveCount(
      answers,
    );
  }

  private showPicturesButton(host: string) {
    return this.page
      .getByRole("main")
      .getByRole("button", { name: this.t("cardFace.showPictures", { host }), exact: true });
  }

  async reveal(): Promise<void> {
    await this.intent("Reveal the answer", async () => {
      await this.page
        .getByRole("main")
        .getByRole("button", { name: this.t("study.reveal"), exact: true })
        .click();
      await expect(this.gradeGroup).toBeVisible();
    });
  }

  /**
   * The answer buttons shown are the `scale`'s, each named by its label
   * and the interval it gives (the answer must be revealed).
   */
  async expectScale(scale: AnswerScale): Promise<void> {
    const labels =
      scale === "minimal"
        ? (["again", "hard", "good", "easy"] as const).map((answer) =>
            this.t(`study.minimal.${answer}`),
          )
        : (["blackout", "wrong", "almost", "hard", "good", "easy"] as const).map((quality) =>
            this.t(`study.quality.${quality}`),
          );
    const buttons = this.gradeGroup.getByRole("button");
    await expect(buttons).toHaveCount(labels.length);
    for (const [index, label] of labels.entries()) {
      // Then "1 day", "15 days": some number of days, whichever the card's state gives.
      await expect(buttons.nth(index)).toHaveAccessibleName(
        new RegExp(`^${escapeRegExp(label)} \\d+ days?$`),
      );
    }
  }

  /** An answer button by its label's key, its name followed by the interval it gives once that is known. */
  private answerButton(key: string): Locator {
    return this.gradeGroup.getByRole("button", {
      name: new RegExp(`^${escapeRegExp(this.t(key))}( |$)`),
    });
  }

  /** The grade's button on whichever scale is shown: "Good" or "4 — Good". */
  private gradeButton(grade: Grade): Locator {
    return this.answerButton(`study.minimal.${grade}`).or(
      this.answerButton(`study.quality.${grade}`),
    );
  }

  /** Answers the revealed card; then the next card is shown, or the session's end. */
  async grade(grade: Grade): Promise<void> {
    await this.intent(`Answer ${grade}`, async () => {
      const { position, total } = await this.position();
      await this.gradeButton(grade).click();
      if (position < total) await this.expectPosition(position + 1, total);
      else await expect(this.finishedMessage).toBeVisible();
    });
  }

  /**
   * Answers the revealed card Again, on the four answer buttons: it goes
   * back into the session, which grows by one.
   */
  async again(): Promise<void> {
    await this.intent("Answer again", async () => {
      const { position, total } = await this.position();
      await this.answerButton("study.minimal.again").click();
      await expect(this.statusLine).toHaveText(
        `${this.t("study.position", { position: position + 1, total: total + 1 })}. ${this.t("study.putBack")}`,
      );
    });
  }

  /** Reveals the card shown, whichever it is, and answers it. */
  async answer(grade: Grade): Promise<void> {
    await this.reveal();
    await this.grade(grade);
  }

  /**
   * Studies every card the session holds, answering each `grade` (and,
   * given a `scale`, checking each card offers its buttons); with
   * `againFirst`, the first card is answered Again (on the four answer
   * buttons) and comes round once more. Returns how many answers and the
   * size the session first said.
   */
  async studyAll({
    grade = "good",
    scale,
    againFirst = false,
  }: {
    grade?: Grade;
    scale?: AnswerScale;
    againFirst?: boolean;
  } = {}): Promise<StudyResult> {
    return this.intent(`Study every card, answering ${grade}`, async () => {
      await expect(this.statusLine.or(this.finishedMessage).or(this.nothingMessage)).toBeVisible();
      if ((await this.nothingMessage.isVisible()) || (await this.finishedMessage.isVisible()))
        return { studied: 0, total: 0 };
      const { total } = await this.position();
      let studied = 0;
      while (!(await this.finishedMessage.isVisible())) {
        await this.reveal();
        if (scale !== undefined) await this.expectScale(scale);
        if (againFirst && studied === 0) await this.again();
        else await this.grade(grade);
        studied += 1;
        if (studied > total + (againFirst ? 1 : 0))
          throw new Error(`The session said ${total} cards but went on past them.`);
      }
      return { studied, total };
    });
  }

  /**
   * "Undo last answer": the answer just given is taken back, and the
   * session is back at card `position` of `total`, which says so.
   */
  async undo(position: number, total: number): Promise<void> {
    await this.intent("Undo the last answer", async () => {
      await this.page
        .getByRole("main")
        .getByRole("button", { name: this.t("study.undo"), exact: true })
        .click();
      await expect(this.statusLine).toHaveText(
        `${this.t("study.position", { position, total })}. ${this.t("study.undone")}`,
      );
    });
  }

  async expectFinished(): Promise<void> {
    await expect(this.finishedMessage).toBeVisible();
  }

  /** "End session": back to Decks. */
  async endSession(): Promise<void> {
    await this.intent("End the session", async () => {
      await this.page
        .getByRole("main")
        .getByRole("button", { name: this.t("study.endSession"), exact: true })
        .click();
      await this.app.chrome.expectBreadcrumbHere("breadcrumbs.decks");
    });
  }
}
