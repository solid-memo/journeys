// SPDX-FileCopyrightText: 2026 Anton Wiklund and Solid Memo contributors
//
// SPDX-License-Identifier: MIT

import AxeBuilder from "@axe-core/playwright";
import { expect, test, type CDPSession, type Page, type TestInfo } from "@playwright/test";
import type { Diagnostics } from "../fixtures.ts";
import { SCHEMES, unexcused, violationLines, WCAG_TAGS } from "../harness/accessibility.ts";
import { text, textPattern, type Locale } from "../harness/strings.ts";
import { CardCreator } from "./CardCreator.ts";
import { CardEditor } from "./CardEditor.ts";
import { Chapter } from "./Chapter.ts";
import { ChapterReview } from "./ChapterReview.ts";
import { Chrome } from "./Chrome.ts";
import { Course } from "./Course.ts";
import { CourseQuestion } from "./CourseQuestion.ts";
import { CssLogin } from "./CssLogin.ts";
import { DeckBrowser } from "./DeckBrowser.ts";
import { DeckCreator } from "./DeckCreator.ts";
import { DeckDetail } from "./DeckDetail.ts";
import { DeckGroups } from "./DeckGroups.ts";
import { DeckList } from "./DeckList.ts";
import { DraftEditor } from "./DraftEditor.ts";
import { GuestOffer } from "./GuestOffer.ts";
import { ImportUrl } from "./ImportUrl.ts";
import { InstanceCreator } from "./InstanceCreator.ts";
import { InstancePicker } from "./InstancePicker.ts";
import { Library } from "./Library.ts";
import { LibraryDeck } from "./LibraryDeck.ts";
import { LibraryPreview } from "./LibraryPreview.ts";
import { Onboarding } from "./Onboarding.ts";
import { Preferences } from "./Preferences.ts";
import { SomethingWentWrong } from "./SomethingWentWrong.ts";
import { Statistics } from "./Statistics.ts";
import { Study } from "./Study.ts";
import { Studio } from "./Studio.ts";
import { Trial } from "./Trial.ts";
import { Validation } from "./Validation.ts";

/**
 * Solid Memo as a journey sees it: one page object per screen, the
 * language the app shows (the page objects find text in it), and the
 * journey's own steps.
 */
export class App {
  /** The language the app shows; Chrome.switchLanguage changes it. */
  locale: Locale = "en";
  private readonly expectedDialogs: RegExp[] = [];
  private devtools: CDPSession | undefined;

  readonly chrome = new Chrome(this);
  readonly onboarding = new Onboarding(this);
  readonly cssLogin = new CssLogin(this);
  readonly guestOffer = new GuestOffer(this);
  readonly instanceCreator = new InstanceCreator(this);
  readonly instancePicker = new InstancePicker(this);
  readonly decks = new DeckList(this);
  readonly groups = new DeckGroups(this);
  readonly deckCreator = new DeckCreator(this);
  readonly deckDetail = new DeckDetail(this);
  readonly deckBrowser = new DeckBrowser(this);
  readonly cardCreator = new CardCreator(this);
  readonly cardEditor = new CardEditor(this);
  readonly study = new Study(this);
  readonly preferences = new Preferences(this);
  readonly statistics = new Statistics(this);
  readonly validation = new Validation(this);
  readonly library = new Library(this);
  readonly libraryDeck = new LibraryDeck(this);
  readonly libraryPreview = new LibraryPreview(this);
  readonly importUrl = new ImportUrl(this);
  readonly studio = new Studio(this);
  readonly draftEditor = new DraftEditor(this);
  readonly trial = new Trial(this);
  readonly course = new Course(this);
  readonly chapter = new Chapter(this);
  readonly chapterReview = new ChapterReview(this);
  readonly question = new CourseQuestion(this);
  readonly crash = new SomethingWentWrong(this);

  constructor(
    readonly page: Page,
    private readonly testInfo: TestInfo,
    private readonly diagnostics: Diagnostics,
  ) {
    page.on("dialog", (dialog) => {
      const at = this.expectedDialogs.findIndex((pattern) => pattern.test(dialog.message()));
      // The page may be gone by the time it is answered: then there is nothing to answer.
      if (at === -1) {
        diagnostics.unexpectedDialogs.push(dialog.message());
        dialog.dismiss().catch(() => {});
      } else {
        this.expectedDialogs.splice(at, 1);
        dialog.accept().catch(() => {});
      }
    });
  }

  t(key: string, vars?: Record<string, string | number>): string {
    return text(this.locale, key, vars);
  }

  tp(key: string, vars?: Record<string, string | number>): RegExp {
    return textPattern(this.locale, key, vars);
  }

  /**
   * Accepts the next dialog (window.confirm) whose message matches; any
   * other fails the journey, and so does the step if it never comes.
   */
  expectDialog(message: RegExp): void {
    this.expectedDialogs.push(message);
  }

  /**
   * Puts the browser in another time zone, which the app's study day is
   * of: the local time moves on (or back) while the clock, which the
   * Solid server checks each request's proof of possession against
   * (within two minutes), stays right. Only in a journey that has turned
   * the config's zone off (`test.use({ timezoneId: "" })`): Chromium takes
   * one override at a time. The zone is in the report and diagnostics.json.
   */
  async setTimeZone(zone: string): Promise<void> {
    await test.step(`Move to the time zone ${zone}`, async () => {
      this.devtools ??= await this.page.context().newCDPSession(this.page);
      await this.devtools.send("Emulation.setTimezoneOverride", { timezoneId: zone });
      this.diagnostics.timezone = zone;
      this.testInfo.annotations.push({ type: "time zone", description: zone });
    });
  }

  /**
   * One step of a journey, as the journey's spec names it ("03 · Set new
   * cards per day to 1"): a group in the report and the trace, with a
   * screenshot of where it left the app, and that screen checked for
   * accessibility, in a step of its own, "Accessibility", so the report
   * says how long the check took apart from the step's own work. A
   * project whose metadata says `accessibility: false` leaves the check
   * out (playwright.config.ts).
   *
   * `in` names the projects the step runs in; elsewhere it is skipped,
   * and the report says so. It is for a step that tests the app's logic,
   * the same in every engine, in a journey the other engines run for
   * what differs between them (docs/testing.md#browsers).
   */
  async step(
    title: string,
    body: () => Promise<void>,
    { in: projects }: { in?: readonly string[] } = {},
  ): Promise<void> {
    if (projects !== undefined && !projects.includes(this.testInfo.project.name)) {
      await test.step
        .skip(title, async () => {});
      return;
    }
    await test.step(title, async () => {
      await body();
      const unmet = this.expectedDialogs.splice(0).map(String);
      expect(unmet, "dialogs this step expected that never came").toEqual([]);
      await this.testInfo.attach(`${title}.png`, {
        body: await this.page.screenshot(),
        contentType: "image/png",
      });
      if (this.testInfo.project.metadata.accessibility !== false) {
        await test.step("Accessibility", () => this.checkAccessibility(title));
      }
    });
  }

  /**
   * Checks the screen a step left the app on with axe, in each theme
   * (harness/accessibility.ts): a violation fails the journey once it
   * ends, as a soft expect, and what axe said of it is attached. A screen
   * of the Solid server's own (its login) is not the app's to check.
   */
  private async checkAccessibility(title: string): Promise<void> {
    const app = new URL(String(this.testInfo.project.use.baseURL)).origin;
    if (new URL(this.page.url()).origin !== app) return;
    const root = this.page.locator("html");
    const shown = await root.getAttribute("data-theme");
    for (const scheme of SCHEMES) {
      // The stylesheet's colors follow the root's data-theme alone (docs/theme.md).
      await root.evaluate((html, theme) => html.setAttribute("data-theme", theme), scheme);
      const { violations } = await new AxeBuilder({ page: this.page })
        .withTags(WCAG_TAGS)
        .analyze();
      const left = unexcused(violations);
      if (left.length === 0) continue;
      const name = `${title} · accessibility, ${scheme}.json`;
      await this.testInfo.attach(name, {
        body: JSON.stringify(left, null, 2),
        contentType: "application/json",
      });
      expect
        .soft(violationLines(left), `accessibility violations, in the ${scheme} theme (${name})`)
        .toEqual([]);
    }
    await root.evaluate((html, theme) => {
      if (theme === null) html.removeAttribute("data-theme");
      else html.setAttribute("data-theme", theme);
    }, shown);
  }
}
