// SPDX-FileCopyrightText: 2026 Anton Wiklund and Solid Memo contributors
//
// SPDX-License-Identifier: MIT

import { expect, test, type Locator } from "@playwright/test";
import { escapeRegExp } from "../harness/strings.ts";
import { chooseLanguageOf } from "./languages.ts";
import { Screen } from "./Screen.ts";
import { cellOf } from "./tables.ts";

/**
 * Solid Memo Studio, in Solid Memo's page at #/studio (docs/studio.md):
 * its old address, its landing page (the same login as Solid Memo's,
 * under the Studio's name, which comes back to the Studio),
 * its instance picker, Home's table of decks (its filter, sort and bulk
 * actions), its Groups screen, the card workbench (its search, sort,
 * selection and bulk edits, with their Undo, its edits of review
 * states, and its moves to another deck), the card inspector (a card's content, its wrong options,
 * its schedule and its history), a deck's schedule, a deck's and the
 * instance's health, its library copies, a deck's about screen (its
 * authors and license), the instance's name and catalog, a deck
 * exported to a file and imported from it, the instance's drafts of
 * releases (made, the next version of a release among them, listed in
 * the sidebar and deleted), the releases it published, its graph (a
 * node reached by keyboard, a leaf found and its neighbors as a table),
 * the decks whose documents are to confirm as their own, and the data a
 * check finds that no repair covers, removed, on the health screen,
 * and its way back
 * to Solid Memo. Its sections are reached from its sidebar, a deck's or
 * a draft's screens from their tabs.
 */
export class Studio extends Screen {
  /** The card inspector's tabs: the card's content, wrong options, schedule and history. */
  private get cardTabs(): Locator {
    return this.page.getByRole("navigation", { name: this.t("studio.card.tabs"), exact: true });
  }

  /** Home's table of the instance's decks ("The decks of {instance}"). */
  decks(instance: string): Locator {
    return this.page.getByRole("table", { name: this.t("studio.decks.caption", { instance }) });
  }

  /**
   * Visits the Studio's old address, /studio/, which sends the visitor on
   * to the Studio in Solid Memo's page: its landing page, before anyone is
   * logged in.
   */
  async visitOldAddress(): Promise<void> {
    await this.intent("Visit the Studio's old address", async () => {
      await this.page.goto("studio/#/");
      await expect(this.page).toHaveURL(/\/#\/studio\/$/);
      await expect(
        this.page.getByRole("heading", { level: 1, name: this.t("studio.name") }),
      ).toBeVisible();
      await expect(this.page.getByText(this.t("studio.tagline"))).toBeVisible();
      await expect(
        this.page.getByRole("button", { name: this.t("onboardingFlow.havePod") }),
      ).toBeVisible();
    });
  }

  /**
   * Back from a login set off at the Studio's landing page: the Studio
   * again, at the route the login left from, not Solid Memo.
   */
  async expectBackAfterLogin(): Promise<void> {
    await this.intent("Come back to the Studio after the login", async () => {
      await expect(this.page).toHaveURL(/\/#\/studio\/$/);
      await expect(
        this.page
          .getByRole("banner")
          .getByRole("link", { name: this.t("studio.name"), exact: true }),
      ).toBeVisible();
    });
  }

  /**
   * Follows the header's link back to Solid Memo for a user with no
   * instance yet: the same session, so still logged in, at Solid Memo's
   * instance creator.
   */
  async backToInstanceCreator(): Promise<void> {
    await this.intent("Go back to Solid Memo to create an instance", async () => {
      await this.page
        .getByRole("banner")
        .getByRole("link", { name: this.t("studio.backToApp") })
        .click();
      await expect(
        this.page.getByRole("heading", { name: this.t("instanceCreator.heading") }),
      ).toBeVisible();
    });
  }

  /**
   * Follows Solid Memo's "Open in Studio" in the instance bar: the Studio
   * opens in the same page, in the same session, so with no login of its own.
   */
  async openFromApp(): Promise<void> {
    await this.intent("Open Solid Memo Studio from Solid Memo", async () => {
      await this.app.chrome.instanceNav.getByRole("link", { name: this.t("studio.open") }).click();
      await expect(this.page).toHaveURL(/\/#\/studio\?instance=/);
      await expect(
        this.page
          .getByRole("banner")
          .getByRole("link", { name: this.t("studio.name"), exact: true }),
      ).toBeVisible();
      await expect(
        this.page.getByRole("banner").getByRole("link", { name: this.t("studio.backToApp") }),
      ).toBeVisible();
    });
  }

  /**
   * The deck's row in the instance's table, by the link its row header
   * names it with: the badges after it (Library, a newer release) are no
   * part of the name.
   */
  row(instance: string, deck: string): Locator {
    return this.decks(instance)
      .getByRole("row")
      .filter({
        has: this.page
          .getByRole("rowheader")
          .filter({ has: this.page.getByRole("link", { name: deck, exact: true }) }),
      });
  }

  /**
   * Home lists the deck, in the instance's table: its name, the groups
   * it is in, its new cards a day, what is due today and its cards, each
   * under its column's header.
   */
  async expectDeck(
    instance: string,
    deck: string,
    figures: { cards: number; due: number; group?: string; newCardsPerDay?: string },
  ): Promise<void> {
    await this.intent(`See ${deck} in the Studio`, async () => {
      await expect(
        this.page.getByRole("heading", { name: this.t("studio.decks.heading"), level: 2 }),
      ).toBeVisible();
      const cell = (column: string) =>
        cellOf(this.decks(instance), this.row(instance, deck), this.t(`studio.decks.${column}`));
      await expect(await cell("group")).toHaveText(
        figures.group ?? this.t("studio.decks.topLevel"),
      );
      // As seen: a cell edited in place holds its button's hidden name too.
      if (figures.newCardsPerDay !== undefined)
        await expect(await cell("newCardsPerDay")).toHaveText(figures.newCardsPerDay, {
          useInnerText: true,
        });
      await expect(await cell("due")).toHaveText(String(figures.due));
      await expect(await cell("cards")).toContainText(String(figures.cards));
    });
  }

  /** Home does not list the deck: the instance has none by that name. */
  async expectNoDeck(instance: string, deck: string): Promise<void> {
    await this.intent(`See no ${deck} in the Studio`, async () => {
      await expect(
        this.page.getByRole("heading", { name: this.t("studio.decks.heading"), level: 2 }),
      ).toBeVisible();
      await expect(this.decks(instance).getByRole("rowheader").first()).toBeVisible();
      await expect(this.row(instance, deck)).toHaveCount(0);
    });
  }

  /** Follows the sidebar's Groups, the screen that arranges the decks as Solid Memo's list does (app.groups). */
  async openGroups(): Promise<void> {
    await this.intent("Open the Groups screen", async () => {
      await this.app.chrome.studioSection("groups");
      await expect(
        this.page.getByRole("heading", { name: this.t("studio.groups.heading"), level: 2 }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("breadcrumbs.groups");
    });
  }

  /** Filters Home's table: only the decks named still show, and the URL holds the filter. */
  async filter(instance: string, text: string, shown: string[]): Promise<void> {
    await this.intent(`Filter the decks by ${text}`, async () => {
      await this.page.getByRole("searchbox", { name: this.t("studio.decks.filter") }).fill(text);
      await expect(this.page).toHaveURL(new RegExp(`[?&]q=${encodeURIComponent(text)}`));
      await expect(this.decks(instance).getByRole("rowheader")).toHaveText(shown);
    });
  }

  /** Sorts Home's table by a column (as its header names it), which says so; the URL holds the sort. */
  async sortBy(instance: string, column: string, order: string[]): Promise<void> {
    await this.intent(`Sort the decks by ${column}`, async () => {
      // Named by its column, then the sort's arrow; the checkboxes' column names "deck" too.
      const name = new RegExp(`^${escapeRegExp(this.t(`studio.decks.${column}`))}`);
      const header = this.decks(instance).getByRole("columnheader", { name });
      await header.getByRole("button").click();
      await expect(header).toHaveAttribute("aria-sort", "ascending");
      await expect(this.page).toHaveURL(new RegExp(`[?&]sort=${column}`));
      await expect(this.decks(instance).getByRole("rowheader")).toHaveText(order);
    });
  }

  /** Checks the decks' checkboxes in Home's table. */
  async select(decks: string[]): Promise<void> {
    await this.intent(`Select ${decks.join(", ")}`, async () => {
      for (const deck of decks) {
        await this.page
          .getByRole("checkbox", { name: this.t("studio.decks.selectDeck", { deck }), exact: true })
          .check();
      }
      await expect(
        this.bulk.getByText(this.t("studio.bulk.selected", { count: decks.length })),
      ).toBeVisible();
    });
  }

  /** Clears the selection: the bulk actions go. */
  async clearSelection(): Promise<void> {
    await this.intent("Clear the selection", async () => {
      await this.bulk.getByRole("button", { name: this.t("studio.bulk.clear") }).click();
      await expect(this.bulk).toHaveCount(0);
    });
  }

  /** Gives the selected decks their own number of new cards per day. */
  async setNewCardsPerDay(count: number, decks: number): Promise<void> {
    await this.intent(`Set the selected decks' new cards per day to ${count}`, async () => {
      await this.pickBulk(this.bulk, "studio.bulk.groups.editDecks", "studio.bulk.pace");
      await this.bulk
        .getByRole("spinbutton", { name: this.t("studio.bulk.newCardsPerDay") })
        .fill(String(count));
      await this.bulk.getByRole("button", { name: this.t("studio.bulk.apply") }).click();
      await this.expectStatus(this.t("studio.bulk.paced", { count: decks }));
    });
  }

  /** Moves the selected decks out of their groups, to the top level. */
  async moveToTopLevel(decks: number): Promise<void> {
    await this.intent("Move the selected decks to the top level", async () => {
      await this.pickBulk(this.bulk, "studio.bulk.groups.editDecks", "studio.bulk.move");
      await this.bulk.getByRole("combobox", { name: this.t("studio.bulk.group") }).selectOption("");
      await this.bulk.getByRole("button", { name: this.t("studio.bulk.apply") }).click();
      await this.expectStatus(
        this.t("studio.bulk.moved", { count: decks, group: this.t("studio.bulk.topLevel") }),
      );
    });
  }

  /**
   * Deletes the selected decks, confirming the question that names them;
   * their rows go, and the status line says so, or, when none is left,
   * Home says the instance has no decks.
   */
  async deleteSelected(instance: string, decks: string[]): Promise<void> {
    await this.intent(`Delete ${decks.join(", ")}`, async () => {
      const names = decks.map((deck) => `“${deck}”`).join(", ");
      await this.bulk
        .getByRole("button", { name: this.t("studio.bulk.remove"), exact: true })
        .click();
      await this.confirm(
        "studio.confirm.deleteDecks",
        this.tp("studio.bulk.removeConfirm", { count: decks.length, names }),
        "studio.bulk.remove",
      );
      const status = this.page
        .getByRole("status")
        .filter({ hasText: this.t("studio.bulk.removed", { count: decks.length }) });
      const empty = this.page.getByRole("main").getByText(this.tp("studio.decks.empty"));
      await expect(status.or(empty)).toHaveCount(1);
      for (const deck of decks) await expect(this.row(instance, deck)).toHaveCount(0);
    });
  }

  /**
   * Follows the selection's Export to import and export, the selected
   * deck checked there (the URL holds it), and saves it as a Turtle file
   * with the user's progress: the browser downloads it, named after the
   * deck. Where the file is kept.
   */
  async exportSelected(instance: string, deck: string): Promise<string> {
    return this.intent(`Export ${deck} with its progress`, async () => {
      await this.bulk
        .getByRole("link", { name: this.t("studio.bulk.export"), exact: true })
        .click();
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.transfer.heading", { instance }),
        }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.transfer.crumb");
      await expect(this.page).toHaveURL(/[?&]deck=/);
      await expect(this.page.getByRole("checkbox", { name: deck, exact: true })).toBeChecked();
      await this.page
        .getByRole("radio", { name: this.t("studio.transfer.formats.turtle") })
        .check();
      await this.page
        .getByRole("checkbox", { name: this.t("studio.transfer.withProgress") })
        .check();
      const downloaded = this.page.waitForEvent("download");
      await this.page
        .getByRole("button", { name: this.t("studio.transfer.exportButton", { count: 1 }) })
        .click();
      const download = await downloaded;
      expect(download.suggestedFilename()).toBe(
        `${deck.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.ttl`,
      );
      await expect(
        this.page
          .getByRole("status")
          .filter({ hasText: this.t("studio.transfer.exported", { count: 1 }) }),
      ).toHaveCount(1);
      // Kept under the name the browser was given, as a user's downloads folder would keep it.
      const path = test.info().outputPath(download.suggestedFilename());
      await download.saveAs(path);
      return path;
    });
  }

  /**
   * Follows the sidebar's import and export, picks the file, sees what
   * it holds (its deck, its cards and its progress), and imports it with
   * its progress: the deck it made is linked.
   */
  async importFile(
    instance: string,
    path: string,
    deck: string,
    cards: number,
    states: number,
  ): Promise<void> {
    await this.intent(`Import ${deck} from its file`, async () => {
      await this.app.chrome.studioSection("transfer");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.transfer.heading", { instance }),
        }),
      ).toBeVisible();
      const chooser = this.page.waitForEvent("filechooser");
      await this.page.getByRole("button", { name: this.t("studio.transfer.choose") }).click();
      await (await chooser).setFiles(path);
      const name = path.split(/[\\/]/).at(-1)!;
      await expect(
        this.page.getByRole("heading", { name: this.t("studio.transfer.file", { name, deck }) }),
      ).toBeVisible();
      await expect(
        this.page.getByText(this.t("studio.transfer.cards", { count: cards }), { exact: true }),
      ).toBeVisible();
      await expect(
        this.page.getByText(this.t("studio.transfer.states", { count: states }), { exact: true }),
      ).toBeVisible();
      await expect(
        this.page.getByRole("checkbox", { name: this.t("studio.transfer.importProgress") }),
      ).toBeChecked();
      await this.page
        .getByRole("button", { name: this.t("studio.transfer.importButton", { instance }) })
        .click();
      await expect(
        this.page.getByRole("status").getByRole("link", { name: deck, exact: true }),
      ).toBeVisible();
    });
  }

  /** The drafts screen's table of the instance's drafts ("Drafts in {instance}"). */
  private drafts(instance: string): Locator {
    return this.page.getByRole("table", { name: this.t("studio.drafts.caption", { instance }) });
  }

  /** Follows the sidebar's link to the instance's drafts of releases. */
  async openDrafts(instance: string): Promise<void> {
    await this.intent("Open the instance's drafts", async () => {
      await this.app.chrome.studioSection("drafts");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.drafts.heading", { instance }),
        }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.drafts.crumb");
    });
  }

  /** Opens the releases the instance published, from the sidebar. */
  async openReleases(instance: string): Promise<void> {
    await this.intent("Open the instance's releases", async () => {
      await this.app.chrome.studioSection("releases");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.releases.heading", { instance }),
        }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.releases.crumb");
    });
  }

  /** The graph's drawing, named by its heading ("Graph of {instance}"). */
  private graph(instance: string): Locator {
    return this.page.getByRole("img", {
      name: this.t("studio.graph.heading", { instance }),
      exact: true,
    });
  }

  /** The aside beside the graph: the node selected. */
  private get graphNode(): Locator {
    return this.page.getByRole("complementary", {
      name: this.t("studio.graph.node.label"),
      exact: true,
    });
  }

  /** Opens the instance's graph from the sidebar, and waits for its nodes to be placed and drawn. */
  async openGraph(instance: string): Promise<void> {
    await this.intent("Open the instance's graph", async () => {
      await this.app.chrome.studioSection("graph");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.graph.heading", { instance }),
        }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.graph.crumb");
      await expect(this.graph(instance)).toBeVisible();
    });
  }

  /**
   * Goes to a node of the drawing with an arrow key, its name and kind
   * then said under it, and opens it with Enter: the aside shows it, by
   * that name, and the URL names it.
   */
  async openGraphNodeByKeyboard(instance: string): Promise<void> {
    await this.intent("Reach a node of the graph by keyboard and open it", async () => {
      const graph = this.graph(instance);
      await graph.focus();
      await this.page.keyboard.press("ArrowRight");
      const line = this.page.locator(`[id="${await graph.getAttribute("aria-describedby")}"]`);
      await expect(line).not.toHaveText(this.t("studio.graph.prompt"));
      const said = (await line.textContent())!;
      const name = said.slice(0, said.lastIndexOf(", "));
      await this.page.keyboard.press("Enter");
      await expect(this.page).toHaveURL(/[?&]node=/);
      await expect(
        this.graphNode.getByRole("heading", { level: 3, name, exact: true }),
      ).toBeVisible();
    });
  }

  /**
   * Finds a node by its address with the graph's search and selects it:
   * the aside names it (`name`) and says why it was not read (`note`, a
   * message's key), for a leaf.
   */
  async findGraphNode(address: string, name: string, note: string): Promise<void> {
    await this.intent(`Find ${address} in the graph`, async () => {
      await this.page.getByRole("searchbox", { name: this.t("studio.graph.search") }).fill(address);
      await this.page
        .getByRole("main")
        .getByRole("listitem")
        .filter({ hasText: address })
        .getByRole("button", { name, exact: true })
        .first()
        .click();
      await expect(
        this.graphNode.getByRole("heading", { level: 3, name, exact: true }),
      ).toBeVisible();
      await expect(this.graphNode.getByText(this.t(note), { exact: true })).toBeVisible();
    });
  }

  /**
   * Clicks the drawing's background, in a corner where no node is: the
   * node selected is let go of, the URL names none, and the aside says
   * how to select one.
   */
  async letGoOfGraphNode(instance: string): Promise<void> {
    await this.intent("Let go of the node selected with a click on the background", async () => {
      await this.graph(instance).click({ position: { x: 4, y: 4 } });
      await expect(this.page).not.toHaveURL(/[?&]node=/);
      await expect(
        this.graphNode.getByText(this.t("studio.graph.node.none"), { exact: true }),
      ).toBeVisible();
    });
  }

  /**
   * Shows only the node selected and its neighbors, as a table: each of
   * `nodes`, by its name, is listed as of its kind (a message's key).
   * Then the graph is drawn whole again.
   */
  async expectNeighborsInTable(
    instance: string,
    nodes: Readonly<Record<string, string>>,
  ): Promise<void> {
    await this.intent("See the node selected and its neighbors as a table", async () => {
      const neighborsOnly = this.page.getByRole("checkbox", {
        name: this.t("studio.graph.neighborsOnly"),
      });
      const asTable = this.page.getByRole("checkbox", { name: this.t("studio.graph.table") });
      await neighborsOnly.check();
      await asTable.check();
      const table = this.page.getByRole("table", { name: this.t("studio.graph.nodes.caption") });
      for (const [name, kind] of Object.entries(nodes)) {
        const row = table.getByRole("row").filter({
          has: this.page.getByRole("rowheader").getByRole("button", { name, exact: true }),
        });
        await expect(await cellOf(table, row, this.t("studio.graph.nodes.kind"))).toHaveText(
          this.t(kind),
        );
      }
      await asTable.uncheck();
      await neighborsOnly.uncheck();
      await expect(this.graph(instance)).toBeVisible();
    });
  }

  /** The releases list one, by its address and its name and version, readable by everyone. */
  async expectRelease(instance: string, url: string, name: string, version: number): Promise<void> {
    await this.intent(`See ${name}, version ${version}, among the releases`, async () => {
      const table = this.page.getByRole("table", {
        name: this.t("studio.releases.caption", { instance }),
      });
      const row = table.getByRole("row").filter({
        has: this.page.getByRole("link", {
          name: this.t("studio.releases.name", { name, version }),
          exact: true,
        }),
      });
      await expect(
        row.getByRole("link", {
          name: this.t("studio.releases.name", { name, version }),
          exact: true,
        }),
      ).toHaveAttribute("href", url);
      await expect(
        row.getByRole("cell", { name: this.t("studio.releases.public"), exact: true }),
      ).toBeVisible();
    });
  }

  /** Starts a draft of a deck of the instance: it opens, and back at the drafts it is listed, being written. */
  async draftDeck(instance: string, deck: string): Promise<void> {
    await this.intent(`Draft a release of ${deck}`, async () => {
      await this.page.getByRole("radio", { name: this.t("studio.drafts.start.fromDeck") }).check();
      await this.page
        .getByRole("combobox", { name: this.t("studio.drafts.deck") })
        .selectOption({ label: deck });
      await this.page
        .getByRole("button", { name: this.t("studio.drafts.create"), exact: true })
        .click();
      await this.expectOpened(deck);
      await this.expectDraft(instance, deck, "deck");
    });
  }

  /** Starts a blank course, named in English: it opens, and back at the drafts it is listed, being written. */
  async draftCourse(instance: string, name: string): Promise<void> {
    await this.intent(`Draft a course, ${name}`, async () => {
      await this.page
        .getByRole("radio", { name: this.t("studio.drafts.start.blankCourse") })
        .check();
      const field = this.page.getByRole("textbox", {
        name: this.t("studio.drafts.name"),
        exact: true,
      });
      await field.fill(name);
      await chooseLanguageOf(this.app, field, "en");
      await this.page
        .getByRole("button", { name: this.t("studio.drafts.create"), exact: true })
        .click();
      await this.expectOpened(name);
      await this.expectDraft(instance, name, "course");
    });
  }

  /**
   * Starts the next version of a release, by its address: the draft is
   * named after the release's title, and is the version after it. It
   * opens; then back at the drafts.
   */
  async draftNextVersion(url: string, title: string, version: number): Promise<void> {
    await this.intent(`Draft version ${version} of ${title}`, async () => {
      await this.page
        .getByRole("radio", { name: this.t("studio.drafts.start.nextVersionOf") })
        .check();
      await this.page.getByRole("textbox", { name: this.t("studio.drafts.release") }).fill(url);
      await this.page
        .getByRole("button", { name: this.t("studio.drafts.create"), exact: true })
        .click();
      await this.expectOpened(title);
    });
  }

  /** The draft just made is open, at its overview; then back at the drafts, from the sidebar. */
  private async expectOpened(title: string): Promise<void> {
    await expect(
      this.page.getByRole("heading", { level: 2, name: title, exact: true }),
    ).toBeVisible();
    await this.app.chrome.studioSection("drafts");
    await this.app.chrome.expectBreadcrumbHere("studio.drafts.crumb");
  }

  /** A draft's row, by its name: its kind, version 1, and being written. */
  private async expectDraft(
    instance: string,
    name: string,
    kind: "deck" | "course",
  ): Promise<void> {
    const row = this.drafts(instance)
      .getByRole("row")
      .filter({ has: this.page.getByRole("rowheader", { name, exact: true }) });
    await expect(row.getByRole("cell")).toHaveText([
      this.t(`studio.drafts.kind.${kind}`),
      "1",
      this.t("studio.drafts.state.writing"),
      this.t("studio.drafts.delete"),
    ]);
  }

  /** Deletes a draft, confirming the question that names it; its row goes. */
  async deleteDraft(instance: string, name: string): Promise<void> {
    await this.intent(`Delete the draft ${name}`, async () => {
      await this.page
        .getByRole("button", {
          name: this.t("studio.drafts.deleteDraft", { draft: name, version: 1 }),
        })
        .click();
      await this.confirm(
        "studio.confirm.deleteDraft",
        this.tp("studio.drafts.deleteConfirm", { draft: name, version: 1 }),
        "studio.drafts.delete",
      );
      await this.expectStatus(this.t("studio.drafts.deleted", { draft: name, version: 1 }));
      await expect(this.drafts(instance).getByRole("rowheader", { name, exact: true })).toHaveCount(
        0,
      );
    });
  }

  /** The sidebar lists the drafts, these alone, each at version 1. */
  async expectSidebarDrafts(drafts: string[]): Promise<void> {
    await this.intent("See the drafts in the sidebar", async () => {
      const list = this.app.chrome.studioSidebar.getByRole("list", {
        name: this.t("studio.shell.draftList"),
        exact: true,
      });
      for (const name of drafts) {
        await expect(
          list
            .getByRole("listitem")
            .filter({ has: this.page.getByRole("link", { name, exact: true }) }),
        ).toContainText(this.t("studio.shell.version", { version: 1 }));
      }
      await expect(list.getByRole("listitem")).toHaveCount(drafts.length);
    });
  }

  /** The card workbench's table of a deck's cards ("The cards of {deck}"). */
  cards(deck: string): Locator {
    return this.page.getByRole("table", { name: this.t("studio.cards.caption", { deck }) });
  }

  /** Follows the deck's number of cards on Home to its cards in the workbench, which lists their fronts. */
  async openCards(instance: string, deck: string, fronts: string[]): Promise<void> {
    await this.intent(`Open the cards of ${deck}`, async () => {
      const name = new RegExp(escapeRegExp(this.t("studio.decks.cardsOf", { deck })));
      await this.row(instance, deck).getByRole("link", { name }).click();
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.cards.heading", { deck }),
        }),
      ).toBeVisible();
      await expect(this.page).toHaveURL(/#\/studio\/cards\?deck=/);
      await expect(this.cards(deck).getByRole("rowheader")).toHaveText(fronts);
    });
  }

  /** Searches the deck's cards: only the fronts named still show, and the URL holds the search. */
  async searchCards(deck: string, text: string, fronts: string[]): Promise<void> {
    await this.intent(`Search the cards for ${text}`, async () => {
      await this.page.getByRole("searchbox", { name: this.t("studio.cards.search") }).fill(text);
      await expect(this.page).toHaveURL(new RegExp(`[?&]q=${encodeURIComponent(text)}`));
      await expect(this.cards(deck).getByRole("rowheader")).toHaveText(fronts);
    });
  }

  /** Empties the search: every card shows again, and the URL holds no search. */
  async clearCardSearch(deck: string, fronts: string[]): Promise<void> {
    await this.intent("Clear the search", async () => {
      await this.page.getByRole("searchbox", { name: this.t("studio.cards.search") }).fill("");
      await expect(this.page).not.toHaveURL(/[?&]q=/);
      await expect(this.cards(deck).getByRole("rowheader")).toHaveText(fronts);
    });
  }

  /** Sorts the deck's cards by a column (its key, as the header names it), which says so; the URL holds the sort. */
  async sortCardsBy(deck: string, column: string, fronts: string[]): Promise<void> {
    await this.intent(`Sort the cards by ${column}`, async () => {
      // Named by its column, then the sort's arrow.
      const name = new RegExp(`^${escapeRegExp(this.t(`studio.cards.column.${column}`))}`);
      const header = this.cards(deck).getByRole("columnheader", { name });
      await header.getByRole("button").click();
      await expect(header).toHaveAttribute("aria-sort", "ascending");
      await expect(this.page).toHaveURL(new RegExp(`[?&]sort=${column}`));
      await expect(this.cards(deck).getByRole("rowheader")).toHaveText(fronts);
    });
  }

  /**
   * Selects the first `count` cards with the keyboard, as the screen's
   * hint says: j goes to the first row from wherever the focus is, x
   * selects it and j moves on. The status line counts them.
   */
  async selectCardsWithKeys(deck: string, count: number): Promise<void> {
    await this.intent(`Select ${count} cards with the keyboard`, async () => {
      await expect(
        this.page.getByText(
          this.t("studio.cards.keys", {
            j: "j",
            k: "k",
            x: "x",
            enter: "Enter",
            shiftJ: "Shift+J",
            shiftK: "Shift+K",
            escape: "Escape",
            f2: "F2",
            dot: ".",
          }),
        ),
      ).toBeVisible();
      await this.page.keyboard.press("j");
      await expect(this.cards(deck).getByRole("rowheader").first().getByRole("link")).toBeFocused();
      for (let index = 0; index < count; index++) {
        await this.page.keyboard.press("x");
        await this.page.keyboard.press("j");
      }
      await this.expectStatus(this.t("studio.cards.selected", { count }));
    });
  }

  /**
   * Moves the focus down the deck's cards with the keyboard, `moves` rows
   * from the first, then back up: the first card selected, the bar of
   * the rows selected shows at the foot of the main content, and the
   * header row at its top, both sticking as the table, longer than the
   * window, scrolls. After each move the row with the focus is in sight
   * between them (WCAG 2.2's Focus Not Obscured). Escape then clears the
   * selection.
   */
  async moveThroughCardsInSight(instance: string, deck: string, moves: number): Promise<void> {
    await this.intent(
      `Move down ${moves} of the cards of ${deck} and back, each in sight`,
      async () => {
        const name = new RegExp(escapeRegExp(this.t("studio.decks.cardsOf", { deck })));
        await this.row(instance, deck).getByRole("link", { name }).click();
        const table = this.cards(deck);
        await expect(table.getByRole("rowheader").nth(moves)).toBeVisible();
        await this.page.keyboard.press("j");
        await expect(table.getByRole("rowheader").first().getByRole("link")).toBeFocused();
        await this.page.keyboard.press("x");
        await this.expectStatus(this.t("studio.cards.selected", { count: 1 }));
        const bar = this.page.getByRole("group", { name: this.t("studio.cardBulk.label") });
        const inSight = async (at: number) => {
          const link = table.getByRole("rowheader").nth(at).getByRole("link");
          await expect(link).toBeFocused();
          const main = (await this.page.locator("main").boundingBox())!;
          const header = (await table.locator("thead").boundingBox())!;
          const foot = (await bar.boundingBox())!;
          const row = (await link.boundingBox())!;
          // Clear of the header row and the bar where they stick, and within the main content.
          expect(row.y, `row ${at} under the header row`).toBeGreaterThanOrEqual(
            Math.max(main.y, header.y + header.height) - 1,
          );
          expect(row.y + row.height, `row ${at} under the bar`).toBeLessThanOrEqual(
            Math.min(main.y + main.height, foot.y) + 1,
          );
        };
        for (let at = 1; at <= moves; at++) {
          await this.page.keyboard.press("j");
          await inSight(at);
        }
        for (let at = moves - 1; at >= 0; at--) {
          await this.page.keyboard.press("k");
          await inSight(at);
        }
        await this.page.keyboard.press("Escape");
        await this.expectStatus(this.t("studio.cards.selected", { count: 0 }));
      },
    );
  }

  /**
   * Finds and replaces in the selected cards: the preview shows the text
   * before and after, and the status line says how many cards changed
   * once the user confirms.
   */
  async findAndReplace(find: string, replace: string, changes: number): Promise<void> {
    await this.intent(`Replace ${find} with ${replace} in the selected cards`, async () => {
      await this.pickBulk(
        this.cardBulk,
        "studio.bulk.groups.editCards",
        "studio.cardBulk.findReplace",
      );
      const form = this.page.getByRole("form", { name: this.t("studio.cardBulk.findReplace") });
      await form.getByRole("textbox", { name: this.t("studio.cardBulk.find") }).fill(find);
      await form
        .getByRole("textbox", { name: this.t("studio.cardBulk.replaceWith") })
        .fill(replace);
      const preview = form.getByRole("region", { name: this.t("studio.cardBulk.preview") });
      await expect(
        preview.getByText(this.t("studio.cardBulk.changes", { count: changes })),
      ).toBeVisible();
      await expect(preview.getByRole("deletion").first()).toHaveText(find);
      await expect(preview.getByRole("insertion").first()).toHaveText(replace);
      await form
        .getByRole("button", { name: this.t("studio.cardBulk.confirmReplace", { count: changes }) })
        .click();
      await this.expectStatus(this.t("studio.cardBulk.done.replaceText", { count: changes }));
    });
  }

  /** The workbench shows the card of this front with this back. */
  async expectBack(deck: string, front: string, back: string): Promise<void> {
    await this.intent(`See ${front}'s back as ${back}`, async () => {
      const row = this.cards(deck)
        .getByRole("row")
        .filter({ has: this.page.getByRole("rowheader", { name: front, exact: true }) });
      // As seen: a cell edited in place holds its button's hidden name too.
      await expect(
        await cellOf(this.cards(deck), row, this.t("studio.cards.column.back")),
      ).toHaveText(back, { useInnerText: true });
    });
  }

  /** Retires the selected cards: they say so in the table. */
  async retireSelectedCards(deck: string, fronts: string[]): Promise<void> {
    await this.intent(`Retire ${fronts.join(", ")}`, async () => {
      await this.cardBulk.getByRole("button", { name: this.t("studio.cardBulk.retire") }).click();
      await this.expectStatus(this.t("studio.cardBulk.done.retire", { count: fronts.length }));
      const tag = this.t("retiredCards.tag");
      for (const front of fronts) {
        await expect(
          this.cards(deck)
            .getByRole("rowheader")
            .filter({ hasText: front })
            .filter({ hasText: tag }),
        ).toHaveCount(1);
      }
    });
  }

  /** Undoes the last edit of the cards: the cards are as they were, the fronts named in use again. */
  async undoCardEdit(deck: string, fronts: string[]): Promise<void> {
    await this.intent("Undo the last edit of the cards", async () => {
      await this.page.getByRole("button", { name: this.t("studio.cardBulk.undo") }).click();
      await this.expectStatus(this.t("studio.cardBulk.undone"));
      for (const front of fronts) {
        await expect(
          this.cards(deck).getByRole("rowheader", { name: front, exact: true }),
        ).toBeVisible();
      }
    });
  }

  /** Opens a card from the workbench in the card inspector, on its content. */
  async openCard(deck: string, front: string): Promise<void> {
    await this.intent(`Inspect the card ${front}`, async () => {
      await this.cards(deck)
        .getByRole("rowheader", { name: front, exact: true })
        .getByRole("link")
        .click();
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.card.heading", { card: front }),
        }),
      ).toBeVisible();
      await expect(this.page).toHaveURL(/#\/studio\/card\?deck=/);
      await expect(
        this.page.getByLabel(this.t("cardContentFields.front"), { exact: true }),
      ).toHaveValue(front);
    });
  }

  /** Writes the inspected card in Markdown, its back as typed, and saves it. */
  async writeBackInMarkdown(back: string): Promise<void> {
    await this.intent(`Write the card in Markdown, its back ${back}`, async () => {
      await this.page
        .getByRole("checkbox", { name: this.t("cardContentFields.markdown"), exact: true })
        .check();
      await this.page.getByLabel(this.t("cardContentFields.back"), { exact: true }).fill(back);
      await this.page.getByRole("button", { name: this.t("card.saveButton"), exact: true }).click();
      await this.expectStatus(this.t("card.saved"));
    });
  }

  /** Follows the deck's tab of its health, from any of its screens, whose line counts its problems. */
  async openDeckHealth(deck: string, problems: number): Promise<void> {
    await this.intent(`Open the health of ${deck}`, async () => {
      await this.app.chrome.studioTab("deck", "health");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.health.deckHeading", { deck }),
        }),
      ).toBeVisible();
      await expect(this.page).toHaveURL(/#\/studio\/health\?instance=.*&deck=/);
      await expect(this.page.getByRole("status").filter({ hasText: /\S/ })).toHaveText(
        problems === 0
          ? this.t("studio.health.allWell")
          : this.t("studio.health.summary", { count: problems }),
      );
    });
  }

  /**
   * Follows the first link of the health's Markdown part named `place`
   * ("Moon, back (Swedish)"): the card inspector, opened at that field,
   * which has the focus.
   */
  async followMarkdownProblem(place: string, field: string): Promise<void> {
    await this.intent(`Follow the Markdown problem of ${place}`, async () => {
      await this.page
        .getByRole("region", { name: this.t("studio.health.markdownHeading") })
        .getByRole("link", { name: place })
        .first()
        .click();
      await expect(this.page).toHaveURL(/#\/studio\/card\?.*field=/);
      await expect(
        this.page.getByLabel(this.t(`cardContentFields.${field}`), { exact: true }),
      ).toBeFocused();
    });
  }

  /** Types into the field that has the focus, in place of what it holds, and saves the card. */
  async fixFocusedField(value: string): Promise<void> {
    await this.intent(`Write ${value} in the field instead`, async () => {
      await this.page.keyboard.press("ControlOrMeta+a");
      await this.page.keyboard.type(value);
      await this.page.getByRole("button", { name: this.t("card.saveButton"), exact: true }).click();
      await this.expectStatus(this.t("card.saved"));
    });
  }

  /** Follows the sidebar's link to the instance's health: every deck is listed, these with no problems. */
  async openInstanceHealth(instance: string, healthy: string[]): Promise<void> {
    await this.intent("Open the instance's health", async () => {
      await this.app.chrome.studioSection("health");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.health.heading", { instance }),
        }),
      ).toBeVisible();
      const decks = this.page.getByRole("region", { name: this.t("studio.health.decksHeading") });
      for (const deck of healthy) {
        await expect(
          decks
            .getByRole("listitem")
            .filter({ has: this.page.getByRole("link", { name: deck, exact: true }) }),
        ).toContainText(this.t("studio.health.badge.healthy"));
      }
    });
  }

  /**
   * Follows the sidebar's link to the instance's library copies: the deck is
   * listed there, copied from the library's current release, so up to
   * date, with nothing to update.
   */
  async openLibraryCopies(instance: string, deck: string): Promise<void> {
    await this.intent("Open the instance's library copies", async () => {
      await this.app.chrome.studioSection("library");
      await this.expectLibraryCopies(instance);
      await this.expectCopyUpToDate(instance, deck);
    });
  }

  /** The library copies' heading and trail. */
  private async expectLibraryCopies(instance: string): Promise<void> {
    await expect(
      this.page.getByRole("heading", {
        level: 2,
        name: this.t("studio.library.heading", { instance }),
      }),
    ).toBeVisible();
    await this.app.chrome.expectBreadcrumbHere("studio.library.crumb");
  }

  /** The library copies' table ("The decks of {instance} copied from the library"). */
  private copies(instance: string): Locator {
    return this.page.getByRole("table", { name: this.t("studio.library.caption", { instance }) });
  }

  /** A copy's row among the library copies, by its deck's name. */
  private copyRow(instance: string, deck: string): Locator {
    return this.copies(instance)
      .getByRole("row")
      .filter({ has: this.page.getByRole("rowheader", { name: deck, exact: true }) });
  }

  /** What a copy's row says under its column's header ("copied", "current", "update"). */
  private copyCell(instance: string, deck: string, column: string): Promise<Locator> {
    return cellOf(
      this.copies(instance),
      this.copyRow(instance, deck),
      this.t(`studio.library.${column}`),
    );
  }

  /** The copy is of the library's current release, `version`: up to date, so it cannot be selected to update. */
  async expectCopyUpToDate(instance: string, deck: string, version?: number): Promise<void> {
    await this.intent(`See ${deck} up to date among the library copies`, async () => {
      if (version !== undefined) {
        await expect(await this.copyCell(instance, deck, "copied")).toHaveText(
          this.t("studio.library.release", { version }),
        );
        await expect(await this.copyCell(instance, deck, "current")).toHaveText(
          this.t("studio.library.release", { version }),
        );
      }
      await expect(await this.copyCell(instance, deck, "update")).toHaveText(
        this.t("studio.library.upToDate"),
      );
      await expect(this.copyRow(instance, deck).getByRole("checkbox")).toHaveCount(0);
    });
  }

  /**
   * Home's badge on the deck's row says the library has release `version`
   * out, and follows it to the library copies.
   */
  async followUpdateBadge(instance: string, deck: string, version: number): Promise<void> {
    await this.intent(`Follow ${deck}'s badge of release ${version}`, async () => {
      await this.decks(instance)
        .getByRole("link", {
          name: `${this.t("studio.library.badge", { version })} ${this.t("studio.library.badgeOf", { deck })}`,
          exact: true,
        })
        .click();
      await this.expectLibraryCopies(instance);
    });
  }

  /** Home has no badge of a newer release on the deck's row: the copy is up to date. */
  async expectNoUpdateBadge(instance: string, deck: string): Promise<void> {
    await this.intent(`See no badge of a newer release on ${deck}`, async () => {
      await expect(this.row(instance, deck)).toBeVisible();
      await expect(
        this.row(instance, deck).getByRole("link", {
          name: this.t("studio.library.badgeOf", { deck }),
        }),
      ).toHaveCount(0);
    });
  }

  /**
   * The copy is of release `from` and the library's current one is `to`:
   * its row says what updating it changes, and it can be selected to
   * update. Moved to with the keyboard (j), the copy is shown beside the
   * table, with what updating keeps and the notes of each release after
   * `from`.
   */
  async readCopyUpgrade(
    instance: string,
    deck: string,
    upgrade: { from: number; to: number; changes: string; kept: string; notes: string[] },
  ): Promise<void> {
    await this.intent(`Read what updating ${deck} to release ${upgrade.to} changes`, async () => {
      const said = this.t("studio.library.changes", {
        version: upgrade.to,
        changes: upgrade.changes,
      });
      await expect(await this.copyCell(instance, deck, "copied")).toHaveText(
        this.t("studio.library.release", { version: upgrade.from }),
      );
      await expect(await this.copyCell(instance, deck, "current")).toHaveText(
        this.t("studio.library.release", { version: upgrade.to }),
      );
      await expect(await this.copyCell(instance, deck, "update")).toHaveText(said);
      await expect(
        this.copyRow(instance, deck).getByRole("checkbox", {
          name: this.t("studio.decks.selectDeck", { deck }),
          exact: true,
        }),
      ).toBeEnabled();
      await this.page.keyboard.press("j");
      const aside = this.page.getByRole("region", { name: deck, exact: true });
      await expect(aside).toContainText(said);
      await expect(aside).toContainText(upgrade.kept);
      await expect(aside.getByRole("listitem")).toHaveText(
        upgrade.notes.map((notes, at) =>
          this.t("libraryUpgradeNotice.releaseNote", { version: upgrade.from + 1 + at, notes }),
        ),
      );
    });
  }

  /** Follows the inspector's tab of the card's wrong options, which the URL holds. */
  async openWrongOptions(count: number): Promise<void> {
    await this.intent("Open the card's wrong options", async () => {
      await this.cardTabs
        .getByRole("link", { name: this.t("studio.card.tab.distractors", { count }) })
        .click();
      await expect(this.page).toHaveURL(/[?&]tab=distractors/);
      await expect(this.wrongOptions).toBeVisible();
    });
  }

  /** Adds a wrong option, in the back's language, which is saved at once and listed. */
  async addWrongOption(text: string, note: string): Promise<void> {
    await this.intent(`Add the wrong option ${text}`, async () => {
      await this.wrongOptions.getByRole("button", { name: this.t("distractorFields.add") }).click();
      await this.wrongOptions
        .getByLabel(this.t("distractorFields.text"), { exact: true })
        .fill(text);
      await this.wrongOptions
        .getByLabel(this.t("distractorFields.note"), { exact: true })
        .fill(note);
      await this.wrongOptions
        .getByRole("button", { name: this.t("distractorFields.addDone"), exact: true })
        .click();
      await this.expectStatus(this.t("card.saved"));
      await expect(this.wrongOption(text)).toContainText(note);
    });
  }

  /** Retires a wrong option: it is kept, marked retired. */
  async retireWrongOption(text: string): Promise<void> {
    await this.intent(`Retire the wrong option ${text}`, async () => {
      await this.wrongOptions
        .getByRole("button", { name: this.t("distractorFields.retireLabel", { option: text }) })
        .click();
      await expect(this.wrongOption(text)).toContainText(this.t("distractorFields.retiredTag"));
      await expect(
        this.wrongOptions.getByRole("button", {
          name: this.t("distractorFields.restoreLabel", { option: text }),
        }),
      ).toBeVisible();
    });
  }

  /** Deletes a wrong option never published, confirming in the Studio's own dialog: it goes. */
  async deleteWrongOption(text: string): Promise<void> {
    await this.intent(`Delete the wrong option ${text}`, async () => {
      await this.wrongOptions
        .getByRole("button", { name: this.t("distractorFields.deleteLabel", { option: text }) })
        .click();
      await this.confirm(
        "distractorFields.deleteHeading",
        this.tp("distractorFields.deleteConfirm", { option: text }),
        "distractorFields.delete",
      );
      await expect(this.wrongOption(text)).toHaveCount(0);
    });
  }

  /**
   * Follows the inspector's tab of the card's schedule, which the URL
   * holds: the card was studied front to back. SM-2's state is shown
   * whichever `scheduler` sets the due days; under FSRS-6, its memory
   * too, below it, saying FSRS-6 sets them.
   */
  async openSchedule(scheduler: "sm2" | "fsrs6"): Promise<void> {
    await this.intent("Open the card's schedule", async () => {
      await this.cardTabs
        .getByRole("link", { name: this.t("studio.card.tab.schedule"), exact: true })
        .click();
      await expect(this.page).toHaveURL(/[?&]tab=schedule/);
      const schedule = this.scheduleOf("frontToBack");
      const sm2 = [
        this.t("studio.schedule.due"),
        this.t("studio.schedule.interval"),
        this.t("studio.schedule.ease"),
        this.t("studio.schedule.repetitions"),
        this.t("studio.schedule.firstReviewed"),
        this.t("studio.schedule.lastReviewed"),
      ];
      const fsrs = [
        this.t("studio.schedule.due"),
        this.t("studio.schedule.stability"),
        this.t("studio.schedule.difficulty"),
        this.t("studio.schedule.recall"),
      ];
      await expect(schedule.getByRole("term")).toHaveText(
        scheduler === "fsrs6" ? [...sm2, ...fsrs] : sm2,
      );
      if (scheduler === "fsrs6")
        await expect(
          schedule.getByText(this.t("studio.schedule.fsrsSets"), { exact: true }),
        ).toBeVisible();
    });
  }

  /** Follows the inspector's tab of the card's history: its answers, newest first, each with its grade and how it was given. */
  async openHistory(
    answers: { grade: string; mode: "recall" | "multiple-choice" }[],
  ): Promise<void> {
    await this.intent("Open the card's history", async () => {
      await this.cardTabs
        .getByRole("link", { name: this.t("studio.card.tab.history"), exact: true })
        .click();
      await expect(this.page).toHaveURL(/[?&]tab=history/);
      const table = this.page.getByRole("table", { name: this.t("studio.history.caption") });
      const rows = table.getByRole("row").filter({ has: this.page.getByRole("cell") });
      await expect(rows).toHaveCount(answers.length);
      for (const [i, answer] of answers.entries()) {
        await expect(rows.nth(i)).toContainText(this.t(`study.quality.${answer.grade}`));
        await expect(rows.nth(i)).toContainText(this.t(`studio.history.mode.${answer.mode}`));
      }
    });
  }

  /**
   * Follows the deck's tab of its schedule: its tiles count
   * the reviews today and in the week to come, and the cards studied; it
   * names no leech.
   */
  async openDeckSchedule(
    deck: string,
    expected: { today: number; week: number; studied: number },
  ): Promise<void> {
    await this.intent(`Open the schedule of ${deck}`, async () => {
      await this.app.chrome.studioTab("deck", "schedule");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.insight.heading", { deck }),
        }),
      ).toBeVisible();
      await expect(this.page).toHaveURL(/#\/studio\/schedule\?deck=/);
      const tile = (label: string) =>
        this.page.getByRole("group", { name: label, exact: true }).getByRole("strong");
      await expect(tile(this.t("studio.insight.today"))).toHaveText(String(expected.today));
      await expect(tile(this.t("studio.insight.week", { count: 7 }))).toHaveText(
        String(expected.week),
      );
      await expect(tile(this.t("studio.insight.scheduled"))).toHaveText(String(expected.studied));
      await expect(tile(this.t("studio.insight.leeches"))).toHaveText("0");
      await expect(
        this.page.getByText(this.t("studio.insight.noLeeches"), { exact: true }),
      ).toBeVisible();
    });
  }

  /** Forgets the card's progress front to back, confirming: it is new that way. */
  async forgetProgress(): Promise<void> {
    await this.intent("Forget the card's progress front to back", async () => {
      await this.scheduleOf("frontToBack")
        .getByRole("button", { name: this.t("studio.schedule.reset") })
        .click();
      await this.confirm(
        "studio.confirm.forgetDirection",
        this.tp("studio.schedule.resetConfirm"),
        "studio.schedule.reset",
      );
      await this.expectStatus(
        this.t("studio.schedule.done.reset", { direction: this.t("common.direction.frontToBack") }),
      );
      await expect(
        this.scheduleOf("frontToBack").getByText(this.t("studio.schedule.new")),
      ).toBeVisible();
    });
  }

  /** Sets the selected cards due today, the day the form offers; the status line counts those studied. */
  async rescheduleSelectedToday(count: number): Promise<void> {
    await this.intent("Set the selected cards due today", async () => {
      await this.pickBulk(
        this.cardBulk,
        "studio.bulk.groups.scheduleCards",
        "studio.cardBulk.reschedule",
      );
      await expect(this.cardBulk.getByLabel(this.t("studio.cardBulk.dueLabel"))).not.toHaveValue(
        "",
      );
      await this.cardBulk.getByRole("button", { name: this.t("studio.bulk.apply") }).click();
      await expect(
        this.page
          .getByRole("status")
          .filter({ hasText: this.tp("studio.cardBulk.done.reschedule", { count }) }),
      ).toHaveCount(1);
    });
  }

  /**
   * Moves the selected cards to another deck of the instance, with their
   * progress (checked to start with): the status line says how many went
   * where, and the workbench lists the fronts left.
   */
  async moveSelectedCards(deck: string, to: string, count: number, left: string[]): Promise<void> {
    await this.intent(`Move the selected cards to ${to}`, async () => {
      await this.pickBulk(
        this.cardBulk,
        "studio.bulk.groups.transferCards",
        "studio.cardBulk.moveTo",
      );
      await this.cardBulk
        .getByRole("combobox", { name: this.t("studio.cardBulk.transfer.deck") })
        .selectOption({ label: to });
      await expect(
        this.cardBulk.getByRole("checkbox", {
          name: this.t("studio.cardBulk.transfer.keepProgress"),
        }),
      ).toBeChecked();
      await this.cardBulk
        .getByRole("button", { name: this.t("studio.cardBulk.transfer.move", { count }) })
        .click();
      await this.expectStatus(this.t("studio.cardBulk.transfer.moved", { count, deck: to }));
      await expect(this.cards(deck).getByRole("rowheader")).toHaveText(left);
    });
  }

  /** The schedule tab's section of one direction. */
  private scheduleOf(direction: "frontToBack" | "backToFront"): Locator {
    return this.page.getByRole("region", { name: this.t(`common.direction.${direction}`) });
  }

  /** Follows a deck's name on Home to what it says of itself. */
  async openAbout(instance: string, deck: string): Promise<void> {
    await this.intent(`Open what ${deck} says of itself`, async () => {
      await this.row(instance, deck)
        .getByRole("rowheader")
        .getByRole("link", { name: deck, exact: true })
        .click();
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.about.heading", { deck }),
        }),
      ).toBeVisible();
      await expect(this.page).toHaveURL(/#\/studio\/about\?deck=/);
    });
  }

  /** Gives the deck one author and a license (by its name), which the about screen then shows. */
  async setAuthorAndLicense(author: string, license: string): Promise<void> {
    await this.intent(`Name ${author} the author, under ${license}`, async () => {
      const section = this.page.getByRole("region", { name: this.t("studio.about.provenance") });
      await section.getByRole("button", { name: this.t("studio.about.editProvenance") }).click();
      await section
        .getByRole("textbox", { name: this.t("studio.about.author", { number: 1 }) })
        .fill(author);
      await section
        .getByRole("combobox", { name: this.t("studio.license.label") })
        .selectOption({ label: license });
      await section.getByRole("button", { name: this.t("studio.about.saveProvenance") }).click();
      await this.expectStatus(this.t("studio.about.saved"));
      await expect(section).toContainText(author);
      await expect(
        section.getByRole("link", { name: new RegExp(escapeRegExp(license)) }),
      ).toBeVisible();
    });
  }

  /** Follows the sidebar's link to the instance's name and catalog. */
  async openInstance(instance: string): Promise<void> {
    await this.intent("Open the instance's name and catalog", async () => {
      await this.app.chrome.studioSection("instance");
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.instance.heading", { instance }),
        }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("studio.instance.crumb");
    });
  }

  /** Renames the instance: the screen names it anew once its registrations say so. */
  async renameInstance(name: string): Promise<void> {
    await this.intent(`Rename the instance ${name}`, async () => {
      await this.page.getByLabel(this.t("studio.instance.nameLabel"), { exact: true }).fill(name);
      await this.page.getByRole("button", { name: this.t("studio.instance.saveName") }).click();
      await this.expectStatus(this.t("studio.about.saved"));
      await expect(
        this.page.getByRole("heading", {
          level: 2,
          name: this.t("studio.instance.heading", { instance: name }),
        }),
      ).toBeVisible();
    });
  }

  /** Describes the instance's catalog and gives it a license (by its name). */
  async describeCatalog(description: string, license: string): Promise<void> {
    await this.intent(`Describe the catalog, under ${license}`, async () => {
      await this.page
        .getByLabel(this.t("studio.instance.description"), { exact: true })
        .fill(description);
      await this.page
        .getByRole("combobox", { name: this.t("studio.license.label") })
        .selectOption({ label: license });
      await this.page.getByRole("button", { name: this.t("studio.instance.saveCatalog") }).click();
      await this.expectStatus(this.t("studio.about.saved"));
    });
  }

  /** The inspector's wrong options. */
  private get wrongOptions(): Locator {
    return this.page.getByRole("group", { name: this.t("distractorFields.legend") });
  }

  /** A wrong option's item in the list, by its text. */
  private wrongOption(text: string): Locator {
    return this.wrongOptions.getByRole("listitem").filter({ hasText: text });
  }

  /** What can be done with the selected cards. */
  private get cardBulk(): Locator {
    return this.page.getByRole("group", { name: this.t("studio.cardBulk.label") });
  }

  /** The notice of the decks whose documents do not say they are the decks' own ("Decks to confirm"). */
  private get unclaimed(): Locator {
    return this.page.getByRole("region", { name: this.t("unclaimedDecks.region"), exact: true });
  }

  /** A deck's item in that notice, by its name. */
  private unclaimedDeck(deck: string): Locator {
    return this.unclaimed
      .getByRole("listitem")
      .filter({ hasText: this.t("unclaimedDecks.deck", { deck }) });
  }

  /** The health screen names the deck as one whose documents, these, do not say they are its own. */
  async expectUnclaimed(deck: string, documents: readonly string[]): Promise<void> {
    await this.intent(`See that the documents of ${deck} are to confirm`, async () => {
      const item = this.unclaimedDeck(deck);
      await expect(item).toBeVisible();
      for (const url of documents)
        await expect(item.getByRole("link").filter({ hasText: url })).toHaveAttribute("href", url);
    });
  }

  /**
   * Confirms, on the health screen, that the deck's documents are its
   * own ("These are this deck's documents", then "Mark them as the
   * deck's"): the notice goes once they say so.
   */
  async claimDocuments(deck: string): Promise<void> {
    await this.intent(`Confirm that the documents of ${deck} are its own`, async () => {
      const item = this.unclaimedDeck(deck);
      await item.getByRole("button", { name: this.t("unclaimedDecks.claim"), exact: true }).click();
      await expect(item).toContainText(this.t("unclaimedDecks.confirm", { deck }));
      await item
        .getByRole("button", { name: this.t("unclaimedDecks.confirmButton"), exact: true })
        .click();
      await expect(this.unclaimed).toHaveCount(0);
    });
  }

  /** The health screen's data check names `subject`, by its address, with this problem. */
  async expectDataProblem(subject: string, problem: string): Promise<void> {
    await this.intent(`See the problem of ${subject}`, async () => {
      await expect(
        this.page
          .getByRole("region", { name: this.t("studio.health.dataHeading"), exact: true })
          .getByRole("listitem")
          .filter({ hasText: subject })
          .filter({ hasText: problem })
          .first(),
      ).toBeVisible();
    });
  }

  /** Removes `subject`, which no repair covers, from the health screen, confirming: it is no longer offered. */
  async removeData(subject: string): Promise<void> {
    await this.intent(`Remove ${subject}`, async () => {
      const remove = this.page.getByRole("button", {
        name: this.t("studio.health.remove", { subject }),
        exact: true,
      });
      await remove.click();
      await this.confirm(
        "studio.confirm.removeData",
        new RegExp(escapeRegExp(this.t("repair.removeConfirm", { url: subject }))),
        "repair.removeButton",
      );
      await expect(remove).toHaveCount(0);
    });
  }

  /** What can be done with the selected decks. */
  private get bulk(): Locator {
    return this.page.getByRole("group", { name: this.t("studio.bulk.label") });
  }

  /** Chooses an action of the selection's bar from its menu: the menu's button, then the item. */
  private async pickBulk(bar: Locator, menu: string, item: string): Promise<void> {
    await bar.getByRole("button", { name: this.t(menu), exact: true }).click();
    await this.page
      .getByRole("menu", { name: this.t(menu), exact: true })
      .getByRole("menuitem", { name: this.t(item), exact: true })
      .click();
  }

  /** Answers the Studio's question (its dialog, by its heading), which says `question`, with its action. */
  private async confirm(heading: string, question: RegExp, action: string): Promise<void> {
    const dialog = this.page.getByRole("dialog", { name: this.t(heading), exact: true });
    await expect(dialog.getByText(question)).toBeVisible();
    await dialog.getByRole("button", { name: this.t(action), exact: true }).click();
    await expect(dialog).toHaveCount(0);
  }

  /** Home's status line (visually hidden) says this. */
  private async expectStatus(message: string): Promise<void> {
    await expect(this.page.getByRole("status").filter({ hasText: message })).toHaveCount(1);
  }

  /** Follows the trail to the instance picker and opens the instance named. */
  async pickInstance(name: string): Promise<void> {
    await this.intent(`Pick the instance ${name}`, async () => {
      await this.app.chrome.breadcrumb("breadcrumbs.instances");
      await expect(
        this.page.getByRole("heading", { name: this.t("instancePicker.heading") }),
      ).toBeVisible();
      await this.page.getByRole("main").getByRole("button", { name, exact: true }).click();
      await this.app.chrome.expectBreadcrumbHere("breadcrumbs.decks");
    });
  }

  /**
   * Follows the header's link back to Solid Memo, at the open instance's
   * decks: the same page and the same session, so still logged in.
   */
  async backToApp(): Promise<void> {
    await this.intent("Go back to Solid Memo", async () => {
      await this.page
        .getByRole("banner")
        .getByRole("link", { name: this.t("studio.backToApp") })
        .click();
      await expect(this.page).toHaveURL(/\/#\/decks\?instance=/);
      await expect(
        this.page
          .getByRole("banner")
          .getByRole("link", { name: this.t("app.documentTitle"), exact: true }),
      ).toBeVisible();
      await this.app.chrome.expectBreadcrumbHere("breadcrumbs.decks");
    });
  }
}
